package Application;


import Classes.Program2;

public class Application2 {
    public static void main(String[] args){
        Program2 program2=new Program2(1400,800);
    }

}
