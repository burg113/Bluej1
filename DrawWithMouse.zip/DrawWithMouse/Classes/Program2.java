package Classes;

import sum.kern.Bildschirm;
import sum.kern.Maus;
import sum.kern.Stift;
import sum.kern.Tastatur;

import java.util.Vector;

public class Program2 {

    int mode=1;

    Bildschirm screen;
    Stift pencil;
    Maus mouse;
    Tastatur keyboard;

    float smoothMousePosX=0;
    float smoothMousePosY=0;
    float smoothnesFactor =0.5f;

    boolean mousePressed=false;


    public Program2(int xSize, int ySize) {
        screen = new Bildschirm(xSize, ySize);
        pencil = new Stift();
        mouse = new Maus();
        keyboard = new Tastatur();


        if(mode==0)zeichneFreihand();
        if(mode==1)zeichneLinien();
        else System.out.println("No part of the program was executed. Check your mode ("+mode+")");

    }

    void zeichneFreihand(){
        smoothMousePosX = mouse.hPosition();
        smoothMousePosY = mouse.vPosition();

        do{
            if(keyboard.wurdeGedrueckt()){
                pencil.radiere();
            }else{
                pencil.normal();
            }

            if(mouse.istGedrueckt()) {
                pencil.bewegeBis(smoothMousePosX,smoothMousePosY);
                pencil.runter();
            }else{
                pencil.hoch();
            }
            moveSmooth(mouse.hPosition(), mouse.vPosition());
        } while (!mouse.doppelKlick());

        screen.gibFrei();
        pencil.gibFrei();
        mouse.gibFrei();


    }

    void zeichneLinien(){
        do{
            if(mouse.istGedrueckt()&&!mousePressed) {
                pencil.hoch();
                pencil.bewegeBis(mouse.hPosition(),mouse.vPosition());
                pencil.zeichneKreis(2);
                mousePressed=true;
            }
            if(!mouse.istGedrueckt()&&mousePressed){
                pencil.runter();
                pencil.bewegeBis(mouse.hPosition(),mouse.vPosition());
                pencil.zeichneKreis(2);
                mousePressed=false;
            }
        } while (!mouse.doppelKlick());

    }




    void moveSmooth(float x,float y){
        smoothMousePosX+=(x-smoothMousePosX)*smoothnesFactor;
        smoothMousePosY+=(y-smoothMousePosY)*smoothnesFactor;
    }



}
