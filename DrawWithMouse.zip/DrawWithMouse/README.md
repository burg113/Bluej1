# Drawing shapes

### This is a school project drawing basic shapes.

Note: By now i know that the BlueJ Librarys already provide most of the functions i wrote myself. (But while writing this code i did not)


9.9.2020
