package Application;


import Classes.FigurstiftProgramm;

public class FigurstiftApplication {
    public static void main(String[] args){
        FigurstiftProgramm meinProgramm=new FigurstiftProgramm(1400,800);
    }

}
