package Application;


import Classes.DartProgram;

public class DartApplication {
    public static void main(String[] args){
        DartProgram dartProgram=new DartProgram(1400,800);
    }

}
