package Application;


import Classes.*;

public class BilliardApplication {
    public static void main(String[] args){
        BilliardProgram biliardProgramm=new BilliardProgram(1400,800);

    }

}
